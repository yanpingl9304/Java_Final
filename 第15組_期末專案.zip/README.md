﻿# Java_Final
original idea:<br/>
We want to create a bot that search for daily weather info and provide other daily life usages.<br/>
Current functions are as follows<br/>
==================================================

weather forecast<br/>
gets weather forecast info from weather.com, using its api to extract data.<br/>
=

calendar usage<br/>
implement google calendar api into our program so that we can modify events just by using the bot.<br/>
=
